package com.example.usedlion.dto;

public enum SaleStatus {
    ONSALE,
    RESERVED,
    SOLDOUT
}